	<div class="  navbar-fixed-buttom " style="margin-top:70px;">
	
		<br/>
		<footer class="text-center">
			<div class="col-md-12">©Copyright by 18111166_UjangMulyana_TIFRP18CNSA_UASWEB1
			<br>
			<br>
			</div>
		</footer>
	</div>
    <script src="../assets/js/jquery.js"></script> 
    <script src="../assets/bootstrap/js/bootstrap.min.js"></script> 
	<script src="../assets/bootstrap/js/moment.js"></script>
	<script src="../assets/bootstrap/js/bootstrap-datetimepicker.min.js"></script>
	<script type="text/javascript">
		$(function () {
			$('#datetimepicker').datetimepicker({
				format: 'YYYY-MM-DD',
            });
			$('#datetimepicker2').datetimepicker({
				format: 'YYYY-MM-DD',
			});
		});
	</script>
  </body>
</html>
