</div> <!-- /container -->
    </div> <!-- /container -->
	
	<div class="  navbar-fixed-buttom " style="margin-top:70px;">
	<!-- navbar navbar-default navbar-fixed-top navbar-blue -->
		<br/>
		<footer class="text-center">
			<div class="col-md-12">©Copyright by 18111166_UjangMulyana_TIFRP18CNSA_UASWEB1
			<br>
			<br>
			</div>
		</footer>
	</div>

    <script src="<?php echo $url ?>assets/js/jquery.js"></script>
  
    <script src="<?php echo $url ?>assets/bootstrap/js/bootstrap.min.js"></script>
  
	
	<script>
    $('.carousel').carousel({
        interval: 5000 //changes the speed
    })
    </script>
	
	<script src="<?php echo $url ?>assets/bootstrap/js/moment.js"></script>
		<script src="<?php echo $url ?>assets/bootstrap/js/bootstrap-datetimepicker.min.js"></script>
		<script type="text/javascript">
			$(function () {
				$('#datetimepicker').datetimepicker({
					format: 'YYYY-MM-DD HH:mm',
                });
				
				
			});
		</script>
  </body>
</html>
